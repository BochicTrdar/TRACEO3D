%==================================================================
%  
%  TRACEO3D: Pekeris all ray information
%  Faro, Dom 16 Abr 2023 15:29:30 WEST 
%  Written by Tordar 
%  
%==================================================================

clear all, close all

addpath /home/orodrig/FORdoc/Traceo3D/M-files

disp('Pekeris waveguide:') 

case_title = 'Pekeris waveguide';

zs   =   25;
Dmax =  100;
rmax = 1000;

%==================================================================
%  
%  Define source data:
%  
%==================================================================

freq = 717; ray_step = rmax/1000; 

xs = [0 0 zs];

nthetas = 21; thetamin = -10; thetamax = 10;
thetas = linspace(thetamin,thetamax,nthetas);

phi = 0; nphi = 1;

 source_data.ds       = ray_step;
 source_data.position = xs;
 source_data.f        = freq;
 source_data.thetas   =  thetas;
 source_data.nthetas  = nthetas; 
 source_data.phi      =  phi;
 source_data.nphi     = nphi; 
 source_data.xbox     = [-rmax rmax];
 source_data.ybox     = [-rmax rmax];
 
%==================================================================
%  
%  Define surface data:
%  
%==================================================================

% This is a homogeneous flat surface, with vacuum over top

surface_data.type  = 'V' ;
surface_data.ptype = 'H' ;
surface_data.itype = 'FL';
surface_data.x     = 1000*[-rmax-1 rmax+1];
surface_data.y     = 1000*[-rmax-1 rmax+1];
surface_data.z     = [0 0;0 0];
surface_data.units = 'W';
surface_data.properties = [0 0 0 0 0];

%==================================================================
%  
%  Define sound speed data:
%  
%==================================================================

c0 = 1482;

ssp_data.ctype = 'ISOV';

ssp_data.x   = [];
ssp_data.y   = [];
ssp_data.z   = [0 Dmax];
ssp_data.c   = c0*[1 1]';

%==================================================================
%  
%  Define bottom data:
%  
%==================================================================

% This is a homogeneous flat bottom, with vacuum below

bottom_data.type  = 'E' ;
bottom_data.ptype = 'H' ;
bottom_data.itype = 'FL';
bottom_data.x     = [-rmax-1 rmax+1];
bottom_data.y     = [-rmax-1 rmax+1];
bottom_data.z     = [1 1;1 1]*Dmax;
bottom_data.units = 'W';
bottom_data.properties = [1700 0.0 1.7 0.7 0];

%==================================================================
%  
%  Define array data:
%  
%==================================================================

xarray = 0;
yarray = 0;
zarray = 0; 

output_data.x	= xarray;
output_data.y	= yarray;
output_data.z	= zarray;
output_data.nxa = 1;
output_data.nya = 1;
output_data.nza = 1;

%==================================================================
%  
%  Define output data:
%  
%==================================================================

output_data.ctype = 'ARI';
output_data.miss  =     1;

%==================================================================
%  
%  Call the function:
%  
%==================================================================

disp('Writing TRACEO3D waveguide input file...')

wtraceo3dinfil('pekeris.in',case_title,source_data,surface_data,ssp_data,bottom_data,output_data);

disp('Calling TRACEO3D...')

system('traceo3d.exe pekeris.in');

load ari

rayname = 'ray00000';

for i = 1:nphi*nthetas

    if i < 10
    
    myexpr =  [ 'rayxyz = ray0000' num2str(i) ';'];
    
    elseif i < 100
     
     myexpr = [ 'rayxyz = ray000' num2str(i) ';'];
     
    elseif i < 1000
    
    myexpr = [ 'rayxyz = ray00' num2str(i) ';'];
    
    else
    
    end 
    
    eval( myexpr )
    
    x = rayxyz(1,:);
    y = rayxyz(2,:);
    z = rayxyz(3,:);
    
    plot3(x,y,-z), hold on
    
end

hold off

disp('done.')
