%==================================================================
%  
%  TRACEO3D: Pekeris upslope ray calculations
%  Faro, Dom 16 Abr 2023 15:35:12 WEST 
%  Written by Tordar 
%  
%==================================================================

clear all, close all

addpath /home/orodrig/FORdoc/Traceo3D/M-files

disp('Pekeris waveguide:') 

case_title = 'Pekeris_waveguide';

%==================================================================
%  
%  Define source data:
%  
%==================================================================

freq = 125; ray_step = 5;

xs = [1 0 50];

nthetas = 6; thetamin = -45; thetamax = 45;
thetas = linspace(thetamin,thetamax,nthetas);

nphi = 11; phimin = -60; phimax = 60;
phi = linspace(phimin,phimax,nphi);

 source_data.ds       = ray_step;
 source_data.position = xs;
 source_data.f        = freq;
 source_data.thetas   =  thetas;
 source_data.nthetas  = nthetas; 
 source_data.phi      =  phi;
 source_data.nphi     = nphi; 
 source_data.xbox     = 1000*[0  5];
 source_data.ybox     = 1000*[-5 5];
 
%==================================================================
%  
%  Define surface data:
%  
%==================================================================

% This is a homogeneous flat surface, with vacuum over top

surface_data.type  = 'V' ;
surface_data.ptype = 'H' ;
surface_data.itype = 'FL';
surface_data.x     = [-1 5100];
surface_data.y     = 1000*[-5.1 5.1];
surface_data.z     = [0 0;0 0];
surface_data.units = 'W';
surface_data.properties = [0 0 0 0 0];

%==================================================================
%  
%  Define sound speed data:
%  
%==================================================================

c0 = 1500;

ssp_data.ctype = 'ISOV';

ssp_data.x   = [];
ssp_data.y   = [];
ssp_data.z   = [0  100]';
ssp_data.c   = [c0  c0]';

%==================================================================
%  
%  Define bottom data:
%  
%==================================================================

% This is a homogeneous flat bottom, with vacuum below

dz = 100;
xbty = [-1 5100];
ybty = [-5.1 5.1]*1000;
zbty = [100 50;100 50];

bottom_data.type  = 'V' ;
bottom_data.ptype = 'H' ;
bottom_data.itype = '2P';
bottom_data.x     = xbty;
bottom_data.y     = ybty;
bottom_data.z     = zbty;
bottom_data.units = 'W';
bottom_data.properties = [2290 1050 1.378 0.76 1.05];

%==================================================================
%  
%  Define array data:
%  
%==================================================================

arrayx = 0;
arrayy = 0;
arrayz = 0; 

output_data.x	= arrayx;
output_data.y	= arrayy;
output_data.z	= arrayz;
output_data.nxa = 1;
output_data.nya = 1;
output_data.nza = 1;

%==================================================================
%  
%  Define output data:
%  
%==================================================================

output_data.ctype = 'RCO';
output_data.miss  = 1;

%==================================================================
%  
%  Call the function:
%  
%==================================================================

disp('Writing TRACEO3D waveguide input file...')

wtraceo3dinfil('pekeris.in',case_title,source_data,surface_data,ssp_data,bottom_data,output_data);

disp('Calling TRACEO3D...')

system('traceo3d.exe pekeris.in');

load rco

rayname = 'ray00000';

for i = 1:nphi*nthetas

    if i < 10
    
    myexpr =  [ 'rayxyz = ray0000' num2str(i) ';'];
    
    elseif i < 100
     
     myexpr = [ 'rayxyz = ray000' num2str(i) ';'];
     
    elseif i < 1000
    
    myexpr = [ 'rayxyz = ray00' num2str(i) ';'];
    
    else
    
    end 
    
    eval( myexpr )
    
    x = rayxyz(1,:);
    y = rayxyz(2,:);
    z = rayxyz(3,:);
    
    plot3(x,y,-z), hold on
    
end

mesh(xbty,ybty,-zbty), colormap('gray')

hold off

disp('done.')
