%==================================================================
%  
%  TRACEO3D: Pekeris upslope pressure calculations
%  Faro, Dom 16 Abr 2023 15:31:24 WEST 
%  Written by Tordar 
%  
%==================================================================

clear all, close all

addpath /home/orodrig/FORdoc/Traceo3D/M-files

disp('Pekeris waveguide:') 

case_title = 'Pekeris_waveguide';

Xmax = 5000; dx = 100; Dmax = 100;

%==================================================================
%  
%  Define source data:
%  
%==================================================================

freq = 125; ray_step = 5;

xs = [0 0 50];

nthetas = 101; thetamin = -45; thetamax = 45;
thetas = linspace(thetamin,thetamax,nthetas);

phi = 0; nphi = 1;

 source_data.ds       = ray_step;
 source_data.position = xs;
 source_data.f        = freq;
 source_data.thetas   =  thetas;
 source_data.nthetas  = nthetas; 
 source_data.phi      =  phi;
 source_data.nphi     = nphi; 
 source_data.xbox     = [-dx   Xmax];
 source_data.ybox     = [-Xmax Xmax];
 
%==================================================================
%  
%  Define surface data:
%  
%==================================================================

% This is a homogeneous flat surface, with vacuum over top

surface_data.type  = 'V' ;
surface_data.ptype = 'H' ;
surface_data.itype = 'FL';
surface_data.x     = [-2*dx    Xmax+dx];
surface_data.y     = [-Xmax-dx Xmax+dx];
surface_data.z     = [0 0;0 0];
surface_data.units = 'W';
surface_data.properties = [0 0 0 0 0];

%==================================================================
%  
%  Define sound speed data:
%  
%==================================================================

c0 = 1500;

ssp_data.ctype = 'ISOV';

ssp_data.x   = [];
ssp_data.y   = [];
ssp_data.z   = [0  Dmax]';
ssp_data.c   = [c0   c0]';

%==================================================================
%  
%  Define bottom data:
%  
%==================================================================

% This is a homogeneous flat bottom, with vacuum below

xbty = [-2*dx Xmax+2*dx];
ybty = [-Xmax-dx Xmax+dx];
zbty = [Dmax Dmax/2;Dmax Dmax/2];

bottom_data.type  = 'E' ;
bottom_data.ptype = 'H' ;
bottom_data.itype = '2P';
bottom_data.x     = xbty;
bottom_data.y     = ybty;
bottom_data.z     = zbty;
bottom_data.units = 'W';
bottom_data.properties = [2290 1050 1.378 0.76 1.05];

%==================================================================
%  
%  Define array data:
%  
%==================================================================

nxa = 101; xarray = linspace(0,Xmax,nxa);
nya =   1; yarray = zeros( size( xarray ) );
nza = 101; zarray = linspace(0,Dmax,nza);

output_data.x	= xarray;
output_data.y	= yarray;
output_data.z	= zarray;
output_data.nxa = nxa;
output_data.nya = nya;
output_data.nza = nza;

%==================================================================
%  
%  Define output data:
%  
%==================================================================

output_data.ctype = 'CPR';
output_data.miss  = 1;

%==================================================================
%  
%  Call the function:
%  
%==================================================================

disp('Writing TRACEO3D waveguide input file...')

wtraceo3dinfil('pekeris.in',case_title,source_data,surface_data,ssp_data,bottom_data,output_data);

disp('Calling TRACEO3D...')

system('traceo3d.exe pekeris.in');

load cpr

tl = -20*log10( abs( pressure ) );

figure
pcolor(xarray,-zarray,tl), shading interp, colorbar,caxis([0 100])

disp('done.')
