%==================================================================
%  
%  TRACEO3D: Pekeris flat bottom ray calculations
%  Faro, Dom 16 Abr 2023 15:36:39 WEST 
%  Written by Tordar 
%  
%==================================================================

clear all, close all

addpath /home/orodrig/FORdoc/Traceo3D/M-files

disp('Pekeris waveguide:') 

case_title = 'Pekeris waveguide';

zs     =  74.2; zarray = 75.8;
z0     = 143.9;
z1     = 152.1; r1   =  988.8;
z2     = 238.2;
rmin   = 100; dr = 2; rmax = 1898.0; 
rarray = [rmin:dr:rmax]; rarraykm = rarray/1000; nra = length( rarray );

%==================================================================
%  
%  Define source data:
%  
%==================================================================

freq = 125; ray_step = 5;

xs = [0 0 zs];

nthetas = 11; thetamin = -14; thetamax = 14;
thetas = linspace(thetamin,thetamax,nthetas);

phi = [-30 0 30]; nphi = length( phi );

 source_data.ds       = ray_step;
 source_data.position = xs;
 source_data.f        = freq;
 source_data.thetas   =  thetas;
 source_data.nthetas  = nthetas; 
 source_data.phi      =  phi;
 source_data.nphi     = nphi; 
 source_data.xbox     = [-rmax rmax];
 source_data.ybox     = [-rmax rmax];
 
%==================================================================
%  
%  Define surface data:
%  
%==================================================================

% This is a homogeneous flat surface, with vacuum over top

surface_data.type  = 'V' ;
surface_data.ptype = 'H' ;
surface_data.itype = 'FL';
surface_data.x     = 1000*[-rmax-1 rmax+1];
surface_data.y     = 1000*[-rmax-1 rmax+1];
surface_data.z     = [0 0;0 0];
surface_data.units = 'W';
surface_data.properties = [0 0 0 0 0];

%==================================================================
%  
%  Define sound speed data:
%  
%==================================================================

c0 = 1482;

ssp_data.ctype = 'ISOV';

ssp_data.x   = [];
ssp_data.y   = [];
ssp_data.z   = [0 z2];
ssp_data.c   = [c0 c0]';

%==================================================================
%  
%  Define bottom data:
%  
%==================================================================

% This is a homogeneous flat bottom, with vacuum below

bottom_data.type  = 'E' ;
bottom_data.ptype = 'H' ;
bottom_data.itype = 'FL';
bottom_data.x     = [-rmax-1 rmax+1];
bottom_data.y     = [-rmax-1 rmax+1];
bottom_data.z     = z1*[1 1;1 1];
bottom_data.units = 'W';
bottom_data.properties = [2290 1050 1.378 0.76 1.05];

%==================================================================
%  
%  Define array data:
%  
%==================================================================

arrayx = 0;
arrayy = 0;
arrayz = 0; 

output_data.x           = arrayx;
output_data.y           = arrayy;
output_data.z           = arrayz;
output_data.nxa         = 1;
output_data.nya         = 1;
output_data.nza         = 1;

%==================================================================
%  
%  Define output data:
%  
%==================================================================

output_data.ctype       = 'RCO';
output_data.miss        = 1;

%==================================================================
%  
%  Call the function:
%  
%==================================================================

disp('Writing TRACEO3D waveguide input file...')

wtraceo3dinfil('pekeris.in',case_title,source_data,surface_data,ssp_data,bottom_data,output_data);

disp('Calling TRACEO3D...')

system('traceo3d.exe pekeris.in');

load rco

rayname = 'ray00000';

for i = 1:nphi*nthetas

    if i < 10
    
    myexpr =  [ 'rayxyz = ray0000' num2str(i) ';'];
    
    elseif i < 100
     
     myexpr = [ 'rayxyz = ray000' num2str(i) ';'];
     
    elseif i < 1000
    
    myexpr = [ 'rayxyz = ray00' num2str(i) ';'];
    
    else
    
    end 
    
    eval( myexpr )
    
    x = rayxyz(1,:);
    y = rayxyz(2,:);
    z = rayxyz(3,:);
    
    plot3(x,y,-z), hold on
    
end

plot3(xs(1),xs(2),-xs(3),'k*','MarkerSize',15)
plot3(xs(1),xs(2),-xs(3),'bo','MarkerSize',15) 

box on, grid on

hold off

disp('done.')
