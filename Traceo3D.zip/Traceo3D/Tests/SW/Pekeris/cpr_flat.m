%==================================================================
%  
%  TRACEO3D: Pekeris flat bottom pressure calculations
%  Faro, Dom 16 Abr 2023 15:33:19 WEST 
%  Written by Tordar
%  
%==================================================================

clear all, close all

addpath /home/orodrig/FORdoc/Traceo3D/M-files

disp('Pekeris waveguide:')

case_title = 'Pekeris waveguide';

zs = 25; Xmax = 1000; Ymax = Xmax; Dmax = 100;

%==================================================================
%  
%  Define source data:
%  
%==================================================================

freq = 717; ray_step = 1;

xs = [0 0 zs];

nthetas = 101; thetamin = -85; thetamax = 85;
thetas = linspace(thetamin,thetamax,nthetas);

phi = 0; 1; nphi = 1;

 source_data.ds       = ray_step;
 source_data.position = xs;
 source_data.f        = freq;
 source_data.thetas   =  thetas;
 source_data.nthetas  = nthetas;
 source_data.phi      =  phi;
 source_data.nphi     = nphi;
 source_data.xbox     = [-Xmax-0.5 Xmax+0.5];
 source_data.ybox     = [-Ymax-0.5 Ymax+0.5];
 
%==================================================================
%  
%  Define surface data:
%  
%==================================================================

% This is a homogeneous flat surface, with vacuum over top

surface_data.type  = 'V' ;
surface_data.ptype = 'H' ;
surface_data.itype = 'FL';
surface_data.x     = [-Xmax-1 Xmax+1];
surface_data.y     = [-Ymax-1 Ymax+1];
surface_data.z     = [0 0;0 0];
surface_data.units = 'W';
surface_data.properties = [0 0 0 0 0];

%==================================================================
%  
%  Define sound speed data:
%  
%==================================================================

c0 = 1500;

ssp_data.ctype = 'ISOV';

ssp_data.x   = [];
ssp_data.y   = [];
ssp_data.z   = [0 Dmax]';
ssp_data.c   = c0*[1 1]';

%==================================================================
%  
%  Define bottom data:
%  
%==================================================================

% This is a homogeneous flat elastic bottom:

bottom_data.type  = 'E' ;
bottom_data.ptype = 'H' ;
bottom_data.itype = 'FL';
bottom_data.x     = [-Xmax-1 Xmax+1];
bottom_data.y     = [-Ymax-1 Ymax+1];
bottom_data.z     = [Dmax Dmax;Dmax Dmax];
bottom_data.units = 'W';
bottom_data.properties = [1700 0 1.7 0.7 0];

%==================================================================
%  
%  Define array data:
%  
%==================================================================

nxa = 201; xarray = linspace(0,Xmax,nxa);
nya =   1; yarray = zeros( 1, nxa );
nza = 201; zarray = linspace(0,Dmax,nza);

output_data.x	= xarray;
output_data.y	= yarray;
output_data.z	= zarray;
output_data.nxa = nxa;
output_data.nya = nya;
output_data.nza = nza;

%==================================================================
%  
%  Define output data:
%  
%==================================================================

output_data.ctype = 'CPR';
output_data.miss  = 1;

%==================================================================
%  
%  Call the function:
%  
%==================================================================

disp('Writing TRACEO3D waveguide input file...')

wtraceo3dinfil('pekeris.in',case_title,source_data,surface_data,ssp_data,bottom_data,output_data);

disp('Calling TRACEO3D...')

system('traceo3d.exe pekeris.in');

load cpr

tl = -20*log10( abs( pressure ) );

figure
hold on
plot(xs(1),-xs(3),'ko',xs(1),-xs(3),'m*','MarkerSize',16) 
pcolor(xarray,-zarray,tl), shading interp, colorbar, caxis([0 90])
hold off
xlabel('Range (m)')
ylabel('Depth (m)')
title('TRACEO3D - Pekeris waveguide, acoustic pressure')

disp('done.')
