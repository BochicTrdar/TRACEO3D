#==================================================================
#  
#  TRACEO3D: LMA CNRS Experimental Data
#  Faro, Dom 16 Abr 2023 15:23:28 WEST 
#  Written by Tordar
#  
#==================================================================

from os import *
import sys
sys.path.append ("/home/orodrig/FORdoc/Traceo3D/Python/")
from wtraceo3dinfil import *
from numpy import *
from scipy.io import *
from matplotlib.pyplot import *
from mpl_toolkits.mplot3d import Axes3D

print('LMA CNRS Tank Experiment:') 

case_title = "LMA_CNRS_Tank_Experiment"

#==================================================================
#  
#  Define source data:
#  
#==================================================================

slope = 4.5
k     = tan( slope*pi/180 )

zs = 10.0
zr = 10.0 
z0 = 40.0

x1 = -z0/k
z1 = k*x1 + z0
Ix1 = x1 * -1
x1 = x1 + Ix1
x2 =   Ix1
z2 = k*x2 + z0
x2 =   x2 *2

xs = array([Ix1, 0.0, zs])

freq = 150.0; ray_step = 1.0
zs   = 10.0
xs   = array([Ix1,0.0,zs])

nthetas = 701; thetamin = -7; thetamax = 7
thetas = linspace(thetamin,thetamax,nthetas)

dphi = 12
sphi = 0.2  

phi0 = 90 - (sphi/2)

phi = arange(phi0,phi0+dphi+sphi,sphi)

nphi = phi.size

xbox = array([x1+2,x2-2])
ybox = array([-5,5050])

source_data = {"ds":ray_step, "position":xs, "xbox":xbox, "ybox":ybox, "f":freq,"thetas":thetas,"nthetas":nthetas,
              "phi":phi, "nphi":nphi}

#==================================================================
#  
#  Define altimetry data:
#  
#==================================================================

btype = 'V' 
ptype = 'H'
itype = 'FL'
x     = array([x1,x2])
y     = array([-100,6000])
z     = zeros((2,2))
units = 'W'
properties = zeros(5)

surface_data = {"btype":btype, "ptype":ptype, "units":units,"itype":itype,"x":x,"y":y,"z":z,"properties":properties}

#==================================================================
#  
#  Define sound speed data:
#  
#==================================================================

c0 = 1488.2 # Page 113

x = zeros(1)
y = zeros(1)
z = array([0.0,z2])
c = array([c0,c0])

ssp_data = {"ctype":"ISOV","x":x,"y":y,"z":z,"c":c}

#==================================================================
#  
#  Define bathymetry data:
#  
#==================================================================

xbty = array([x1,x2])
ybty = array([-0.006,   6])*1000
zbty = array([[z1,z2],[z1,z2]])

btype = 'E' 
ptype = 'H'
itype = '2P'
x     = xbty
y     = ybty
z     = zbty
units = 'W'

properties = array([1700, 0, 1.99, 0.5, 0])

bottom_data = {"btype":btype, "ptype":ptype, "units":units,"itype":itype,"x":x,"y":y,"z":z,"properties":properties}

#==================================================================
#  
#  Define output data:
#  
#==================================================================

xarray = array([Ix1   ])
yarray = array([5000.0])
zarray = array([10.0  ])

nxa = 1
nya = 1
nza = 1

miss = 0.01

output_data = {"ctype":"EIS","array_shape":"VRY","x":xarray,"y":yarray,"z":zarray,
               "nxa":nxa,"nya":nya,"nza":nza,"miss":miss}

print('Writing TRACEO3D waveguide input file...')

wtraceo3dinfil("lmacnrs.in",case_title,source_data,surface_data,ssp_data,bottom_data,output_data)

system('traceo3d.exe lmacnrs.in')

print('Reading the output data...')

data = loadmat('eig.mat')

nerays3d = data['nerays3d'][0]
nerays3d = int( nerays3d )

fig = figure(1)
ax = fig.add_subplot(111, projection="3d")

for i in range(1,nerays3d+1):

   if i < 10:
      rayname = 'e000000' + str(i)
   elif i < 100:
      rayname = 'e00000'  + str(i)
   elif i < 1000:
      rayname = 'e0000'   + str(i)
   elif i < 10000:
      rayname = 'e000'    + str(i)
   else:
      rayname = 'e00'     + str(i)   

   rayi = data[rayname]
   
   x = rayi[0,]
   y = rayi[1,]   
   z = rayi[2,]
   ax.plot(x,y,-z)

ax.text(xs[0], xs[1], -xs[2], "o", color='black', ha='center', va='center',fontsize=16)   
ax.set_xlabel('X (m)')
ax.set_ylabel('Y (m)')
ax.set_zlabel('Z (m)')
show()

print('done.')
