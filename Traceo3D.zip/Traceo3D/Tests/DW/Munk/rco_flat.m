%==================================================================
%  
%  TRACEO3D: Munk flat ray calculations
%  Faro, Dom 16 Abr 2023 17:09:04 WEST 
%  Written by Tordar 
%  
%==================================================================

clear all, close all

addpath /home/orodrig/FORdoc/Traceo3D/M-files/

disp('Munk Profile Test:') 

case_title = 'Munk profile';

%==================================================================
%  
%  Define source data:
%  
%==================================================================

freq = 50; ray_step = 101;

xs = [0 0 1000];

nthetas = 51; nphi = 4; 
 
thetamin = -14; thetamax = 14; 
thetas = linspace(thetamin,thetamax,nthetas);

phi = [0 90 180 270]; nphi = length( phi );

source_data.ds       = ray_step;
source_data.position = xs;
source_data.f	     = freq;
source_data.thetas   =  thetas;
source_data.nthetas  = nthetas;
source_data.phi      =  phi;
source_data.nphi     = nphi;
source_data.xbox     = 1000*[-100 100];
source_data.ybox     = 1000*[-100 100];
 
%==================================================================
%  
%  Define surface data:
%  
%==================================================================

% This is a homogeneous flat surface, with vacuum over top

surface_data.type  = 'V' ;
surface_data.ptype = 'H' ;
surface_data.itype = 'FL';
surface_data.x     = 1000*[-101 101];
surface_data.y     = 1000*[-101 101];
surface_data.z     = [0 0;0 0];
surface_data.units = 'W';
surface_data.properties = [0 0 0 0 0];

%==================================================================
%  
%  Define sound speed data:
%  
%==================================================================

depths = linspace(0,5000,1001);

c1 = 1500; z1 = 1300; B = 1.3e3; epsilon = 7.37e-3;

eta = 2*( depths - z1 )/B; 

c = c1*( 1 + epsilon*( eta + exp( -eta ) - 1 ) );  

ssp_data.ctype = 'C00Z';

ssp_data.z   = depths;
ssp_data.x   = [];
ssp_data.y   = [];
ssp_data.c   = c(:);

%data = [depths(:) c(:)];save -ascii c0.dat data

%==================================================================
%  
%  Define object data:
%  
%==================================================================

object_data.nobjects = 0; % Number of objects

%==================================================================
%  
%  Define bottom data:
%  
%==================================================================

% This is a homogeneous flat bottom, with vacuum below

bottom_data.type  = 'V' ;
bottom_data.ptype = 'H' ;
bottom_data.itype = 'FL';
bottom_data.x     = 1000*[-101 101];
bottom_data.y     = 1000*[-101 101];
bottom_data.z     = 5000*[1 1;1 1];
bottom_data.units = 'W';
bottom_data.properties = [0 0 0 0 0];

%==================================================================
%  
%  Define array data:
%  
%==================================================================

arrayx = 25*1000;
arrayy = 25*1000;
arrayz = 2500; 

output_data.x           = arrayx;
output_data.y           = arrayy;
output_data.z           = arrayz;
output_data.nxa         = 1;
output_data.nya         = 1;
output_data.nza         = 1;

%==================================================================
%  
%  Define output data:
%  
%==================================================================

output_data.ctype       = 'RCO';
output_data.miss        = 1;

%==================================================================
%  
%  Call the function:
%  
%==================================================================

disp('Writing TRACEO3D waveguide input file...')

wtraceo3dinfil('munk.in',case_title,source_data,surface_data,ssp_data,bottom_data,output_data);

disp('Calling TRACEO3D...')

system('traceo3d.exe munk.in');

load rco

rayname = 'ray00000';

for i = 1:nphi*nthetas

    if i < 10
    
    myexpr =  [ 'rayxyz = ray0000' num2str(i) ';'];
    
    elseif i < 100
     
     myexpr = [ 'rayxyz = ray000' num2str(i) ';'];
     
    elseif i < 1000
    
    myexpr = [ 'rayxyz = ray00' num2str(i) ';'];
    
    else
    
    end 
    
    eval( myexpr )
    
    x = rayxyz(1,:);
    y = rayxyz(2,:);
    z = rayxyz(3,:);
    
    plot3(x,y,-z), hold on
    
end

hold off

disp('done.')
