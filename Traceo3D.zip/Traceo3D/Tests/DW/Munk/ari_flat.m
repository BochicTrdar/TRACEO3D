%==================================================================
%  
%  TRACEO3D: Flat surface and bottom, all ray information
%  Faro, Dom 16 Abr 2023 17:07:26 WEST 
%  Written by Tordar 
%  
%==================================================================

clear all, close all

addpath /home/orodrig/FORdoc/Traceo3D/M-files

disp('Munk Profile Test:') 

case_title = 'Munk profile';

%==================================================================
%  
%  Define source data:
%  
%==================================================================

freq = 50; ray_step = 101;

xs = [0 0 1000];

nthetas = 51; nphi = 4; 

thetamin = -20; thetamax = 20;
thetas = linspace(thetamin,thetamax,nthetas);

phi = [0 90 180 270]; nphi = length( phi );

 source_data.ds       = ray_step;
 source_data.position = xs;
 source_data.f        = freq;
 source_data.thetas   = thetas;
 source_data.phi      = phi;
 source_data.nthetas  = nthetas; 
 source_data.nphi     = nphi;
 source_data.xbox     = 1000*[-100 100];
 source_data.ybox     = 1000*[-100 100];
 
%==================================================================
%  
%  Define surface data:
%  
%==================================================================

% This is a homogeneous flat surface, with vacuum over top

surface_data.type  = 'V' ;
surface_data.ptype = 'H' ;
surface_data.itype = 'FL';
surface_data.x     = 1000*[-101 101];
surface_data.y     = 1000*[-101 101];
surface_data.z     = [0 0;0 0];
surface_data.units = 'W';
surface_data.properties = [0 0 0 0 0];

%==================================================================
%  
%  Define sound speed data:
%  
%==================================================================

c1 = 1500; z1 = 1300;

depths = linspace(0,5000,1001);

c = munk( depths, z1, c1 );

ssp_data.ctype = 'C00Z';

ssp_data.z   = depths;
ssp_data.x   = [];
ssp_data.y   = [];
ssp_data.c   = c(:);

%data = [depths(:) c(:)];save -ascii c0.dat data

%==================================================================
%  
%  Define object data:
%  
%==================================================================

object_data.nobjects = 0; % Number of objects

% Some object dada to use later:

%n = 11; R0 = 0.5*1000; 

% Be careful with this! you already defined phi and theta above!
%phis   = linspace(0,pi/2,n); Phi    = repmat(phis   ,n,1);
%thetas = linspace(0,2*pi,n); Thetas = repmat(thetas',1,n); 

%R = R0*ones(n);

%[xo,yo,zo] = sph2cart(Thetas,Phi,R);

%figure(1),hold on
%surfl(xo,yo, zo),%shading interp, colormap('gray') 
%surfl(xo,yo,-zo),shading interp, colormap('gray')
%hold off
%return 

%zd =  zo + 2*1000;
%zu = -zo + 2*1000;

%figure(1),hold on
%surfl(xo,yo,zu),
%surfl(xo,yo,zd),
%shading interp, colormap('gray')
%hold off
%return 

%object_data.type( 1  ) =  'H' ;
%object_data.ptype(1  ) =  'V' ;
%object_data.itype(1,:) =  '2P';
%object_data.units(1  ) =  'W' ;

%object_data.x( 1,:,:) = xo;
%object_data.y( 1,:,:) = yo;
%object_data.zu(1,:,:) = zu;
%object_data.zd(1,:,:) = zd;

%object_data.npobjects( 1)   = n;
%object_data.properties(1,:) = [0 0 0 0 0];

%==================================================================
%  
%  Define bottom data:
%  
%==================================================================

% This is a homogeneous flat bottom, parameters from the acoustic toolbox:

bottom_data.type  = 'E' ;
bottom_data.ptype = 'H' ;
bottom_data.itype = 'FL';
bottom_data.x     = 1000*[-101 101];
bottom_data.y     = 1000*[-101 101];
bottom_data.z     = 5000*[1 1;1 1];
bottom_data.units = 'W';
bottom_data.properties = [1600 0 1.8 0.8 0];

%==================================================================
%  
%  Define array data:
%  
%==================================================================

arrayx = 25*1000;
arrayy = 25*1000;
arrayz = 2500;

output_data.x           = arrayx;
output_data.y           = arrayy;
output_data.z           = arrayz;
output_data.nxa         = 1;
output_data.nya         = 1;
output_data.nza         = 1;

%==================================================================
%  
%  Define output data:
%  
%==================================================================

output_data.ctype       = 'ARI';
output_data.miss        = 1;

%==================================================================
%  
%  Call the function:
%  
%==================================================================

disp('Writing TRACEO3D waveguide input file...')

wtraceo3dinfil('munk.in',case_title,source_data,surface_data,ssp_data,bottom_data,output_data);

disp('Calling TRACEO3D...')

system('traceo3d.exe munk.in');

load ari

rayname = 'ray00000';

for i = 1:nphi*nthetas

    if i < 10
    
    myexpr =  [ 'rayxyz = ray0000' num2str(i) ';'];
    
    elseif i < 100
     
     myexpr = [ 'rayxyz = ray000' num2str(i) ';'];
     
    elseif i < 1000
    
    myexpr = [ 'rayxyz = ray00' num2str(i) ';'];
    
    else
    
    end 
    
    eval( myexpr )
    
    x = rayxyz(1,:);
    y = rayxyz(2,:);
    z = rayxyz(3,:);
    
    plot3(x,y,-z), hold on
    
end

hold off

disp('done.')
