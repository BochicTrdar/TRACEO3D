%==================================================================
%  
%  TRACEO3D: Munk flat waveguide pressure calculations
%  Faro, Dom 16 Abr 2023 17:07:58 WEST 
%  Written by Tordar 
%  
%==================================================================

clear all, close all

addpath /home/orodrig/FORdoc/Traceo3D/M-files

disp('Munk Profile Test:') 

case_title = 'Munk profile';

%==================================================================
%  
%  Define source data:
%  
%==================================================================

freq = 50; ray_step = 10; 

Xmaxkm = 100; Xmax = Xmaxkm*1000; Dmax = 5000;

xs = [0 0 1000];

nthetas = 51; thetamax = 14; thetas = linspace(-thetamax,thetamax,nthetas);

phi = 0; nphi = 1;

 source_data.ds       = ray_step;
 source_data.position = xs;
 source_data.f        = freq;
 source_data.thetas   =  thetas;
 source_data.nthetas  = nthetas; 
 source_data.phi      =  phi;
 source_data.nphi     = nphi; 
 source_data.xbox     = [-Xmax Xmax];
 source_data.ybox     = [-Xmax Xmax];
 
%==================================================================
%  
%  Define surface data:
%  
%==================================================================

% This is a homogeneous flat surface, with vacuum over top

surface_data.type  = 'V' ;
surface_data.ptype = 'H' ;
surface_data.itype = 'FL';
surface_data.x     = 1000*[-Xmaxkm-1 Xmaxkm+1];
surface_data.y     = 1000*[-Xmaxkm-1 Xmaxkm+1];
surface_data.z     = [0 0;0 0];
surface_data.units = 'W';
surface_data.properties = [0 0 0 0 0];

%==================================================================
%  
%  Define sound speed data:
%  
%==================================================================

c1 = 1500; z1 = 1300;

depths = linspace(0,Dmax,1001);

c = munk( depths, z1, c1 );

ssp_data.ctype = 'C00Z';

ssp_data.z   = depths;
ssp_data.x   = [];
ssp_data.y   = [];
ssp_data.c   = c(:);

%==================================================================
%  
%  Define object data:
%  
%==================================================================

object_data.nobjects = 0; % Number of objects

%==================================================================
%  
%  Define bottom data:
%  
%==================================================================

bottom_data.type  = 'E' ;
bottom_data.ptype = 'H' ;
bottom_data.itype = 'FL';
bottom_data.x     = 1000*[-Xmaxkm-1 Xmaxkm+1];
bottom_data.y     = 1000*[-Xmaxkm-1 Xmaxkm+1];
bottom_data.z     = Dmax*[1 1;1 1];
bottom_data.units = 'W';
bottom_data.properties = [1550.0 600.0 2.0 0.1 0.0];

%==================================================================
%  
%  Define output data:
%  
%==================================================================

nxa = 501; xarray = linspace(0,Xmax,nxa);
nya =   1; yarray = 0;
nza = 501; zarray = linspace(0,Dmax,nza);

output_data.ctype = 'CPR'; 
output_data.x     = xarray;
output_data.y     = yarray;
output_data.z     = zarray;
output_data.nxa   = nxa;
output_data.nya   = nya;
output_data.nza   = nza;
output_data.miss  = 1;

%==================================================================
%  
%  Call the function:
%  
%==================================================================

disp('Writing TRACEO3D waveguide input file...')

wtraceo3dinfil('munk.in',case_title,source_data,surface_data,ssp_data,bottom_data,output_data);

disp('Calling TRACEO3D...')

tic
system('traceo3d.exe munk.in');
toc

disp('Reading the output data...')

counter = 0;

load cpr

tl = -20*log10( abs(pressure) ); 

tej = flipud( jet( 256 ) );

figure(1), hold on
plot(xs(1),-xs(3),'ko',xs(1),-xs(3),'m*','MarkerSize',16) 
pcolor(xarray,-zarray,tl), shading interp, colormap( tej ), caxis([50 120]), colorbar
axis([0 Xmax -Dmax 0])
hold off
xlabel('Range (m)')
ylabel('Depth (m)')
title('TRACEO3D - Munk profile')

disp('done.')
