%==================================================================
%  
%  TRACEO3D: Munk profile + ray calculations + Gaussian sea mountain
%  Faro, Dom 16 Abr 2023 17:08:29 WEST 
%  Written by Tordar 
%  
%==================================================================

clear all, close all

addpath /home/orodrig/FORdoc/Traceo3D/M-files

disp('Munk Profile Test:') 

case_title = 'Munk profile';

%==================================================================
%  
%  Define source data:
%  
%==================================================================

freq = 50; ray_step = 1001;

xs = [-95*1000 0 1000];

nthetas = 11; 
 
thetamin = -30; thetamax = 30;
thetas = linspace(thetamin,thetamax,nthetas);

 phi = [-15 0 15]; nphi = length(phi);

 source_data.ds       = ray_step;
 source_data.position = xs;
 source_data.f        = freq;
 source_data.thetas   = thetas;
 source_data.phi      = phi;
 source_data.nthetas  = nthetas;
 source_data.nphi     = nphi; 
 source_data.xbox     = 1000*[-100 100];
 source_data.ybox     = 1000*[-100 100];
 
%==================================================================
%  
%  Define surface data:
%  
%==================================================================

% This is a homogeneous flat surface, with vacuum over top


surface_data.type  = 'V' ;
surface_data.ptype = 'H' ;
surface_data.itype = 'FL';
surface_data.x     = [-101 101]*1000;
surface_data.y     = [-101 101]*1000;
surface_data.z     = [0 0;0 0];
surface_data.units = 'W';
surface_data.properties = [0 0 0 0 0];

%==================================================================
%  
%  Define sound speed data:
%  
%==================================================================

c1 = 1500; z1 = 1300;

depths = linspace(0,5000,1001);

c = munk( depths, z1, c1 );

ssp_data.ctype = 'C00Z';

ssp_data.z   = depths;
ssp_data.x   = [];
ssp_data.y   = [];
ssp_data.c   = c(:);

%data = [depths(:) c(:)];save -ascii c0.dat data

%==================================================================
%  
%  Define object data:
%  
%==================================================================

object_data.nobjects = 0; % Number of objects

%==================================================================
%  
%  Define bottom data:
%  
%==================================================================

% Gaussian sea mountain, parameters from the acoustic toolbox:

z0 = 2500; sgma = 5e4; nbtyx = 21; nbtyy = 21;
xmax = 101; xmax = xmax*1000; xmin = -xmax;
ymax = 101; ymax = ymax*1000; ymin = -ymax;
xbty = linspace(xmin,xmax,nbtyx);
ybty = linspace(ymin,ymax,nbtyy);
[X,Y] = meshgrid(xbty,ybty);
R = sqrt( X.^2 + Y.^2 )/sgma;
zbty = 5000-z0*exp( -R.^2 );

%figure(1),mesh(xbty,ybty,zbty)

bottom_data.type  = 'E' ;
bottom_data.ptype = 'H' ;
bottom_data.itype = '2P';
bottom_data.x     = xbty;
bottom_data.y     = ybty;
bottom_data.z     = zbty;
bottom_data.units = 'W';
bottom_data.properties = [1600 0 1.8 0.8 0];

%==================================================================
%  
%  Define output data:
%  
%==================================================================

arrayx = 25*1000;
arrayy = 25*1000;
arrayz = 2500;

output_data.x           = arrayx;
output_data.y           = arrayy;
output_data.z           = arrayz;
output_data.nxa         = 1;
output_data.nya         = 1;
output_data.nza         = 1;

%==================================================================
%  
%  Define output data:
%  
%==================================================================

output_data.ctype       = 'RCO';
output_data.miss        = 1;

%==================================================================
%  
%  Call the function:
%  
%==================================================================

disp('Writing TRACEO3D waveguide input file...')

wtraceo3dinfil('munk.in',case_title,source_data,surface_data,ssp_data,bottom_data,output_data);

disp('Calling TRACEO3D...')

system('traceo3d.exe munk.in');

load rco

rayname = 'ray00000';

for i = 1:nphi*nthetas

    if i < 10
    
    myexpr =  [ 'rayxyz = ray0000' num2str(i) ';'];
    
    elseif i < 100
     
     myexpr = [ 'rayxyz = ray000' num2str(i) ';'];
     
    elseif i < 1000
    
    myexpr = [ 'rayxyz = ray00' num2str(i) ';'];
    
    else
    
    end 
    
    eval( myexpr )
    
    x = rayxyz(1,:);
    y = rayxyz(2,:);
    z = rayxyz(3,:);
    
    plot3(x,y,-z), hold on
    
end

mesh(xbty,ybty,-zbty)
hold off

disp('done.')
