function wtraceo3dinfil( filename, thetitle, source_info, surface_info, ssp_info, bathymetry_info, output_info )

% Writes TRACEO3D input (waveguide) file. 
%
% SYNTAX: wtraceo3dinfil( filename, title, source, surface, ssp, bottom, output )
%

%*******************************************************************************
% Faro, Sex 14 Abr 2023 00:20:06 WEST 
% Written by Tordar 
%*******************************************************************************

separation_line(1:80) = '-';

%*******************************************************************************
% Get source data: 

ds       = source_info.ds;
xs       = source_info.position(1);
ys       = source_info.position(2);
zs       = source_info.position(3);
freq     = source_info.f;
xbox     = source_info.xbox;
ybox     = source_info.ybox;

 thetas  = source_info.thetas;
nthetas  = source_info.nthetas;

 phi    = source_info.phi; 
nphi    = source_info.nphi;

%*******************************************************************************
% Get surface data:

 atype = surface_info.type ;
aptype = surface_info.ptype;
aitype = surface_info.itype;
  xati = surface_info.x    ; natix = length( xati(1,:) );
  yati = surface_info.y    ; natiy = length( yati(1,:) );
  zati = surface_info.z    ; natiz = length( zati(1,:) );
atiu   = surface_info.units;
aproperties = surface_info.properties;

%*******************************************************************************
% Get sound speed data: 

ctype = ssp_info.ctype;

c0 = ssp_info.c;
x0 = ssp_info.x;
y0 = ssp_info.y;
z0 = ssp_info.z;

%*******************************************************************************
% Get bathymetry data:

 btype = bathymetry_info.type ;
bptype = bathymetry_info.ptype;
bitype = bathymetry_info.itype;
  xbty = bathymetry_info.x    ; nbtyx = length( xbty(1,:) );
  ybty = bathymetry_info.y    ; nbtyy = length( ybty(1,:) );
  zbty = bathymetry_info.z    ; nbtyz = length( zbty(1,:) );
btyu   = bathymetry_info.units;
bproperties = bathymetry_info.properties;

%*******************************************************************************
% Get output options: 

  calc_type = output_info.ctype;
array_x     = output_info.x    ;
array_y     = output_info.y    ;
array_z     = output_info.z    ;
array_miss  = output_info.miss ;
narrayx     = output_info.nxa  ;
narrayy     = output_info.nya  ;
narrayz     = output_info.nza  ;

%*******************************************************************************
% Write the INPFIL: 
 
fid = fopen(filename,'w');

fprintf(fid,'%s\n',thetitle);

% Write source info: 

fprintf(fid,'%s\n',separation_line);
fprintf(fid,'%f\n',ds);
fprintf(fid,'%f %f %f\n',xs,ys,zs);
fprintf(fid,'%f\n',freq);
fprintf(fid,'%f %f\n',xbox(1),xbox(2));
fprintf(fid,'%f %f\n',ybox(1),ybox(2));
fprintf(fid,'%d\n',nthetas);
if nthetas == 1
fprintf(fid,'%f\n',thetas);
elseif nthetas > 1
fprintf(fid,'%f %f\n',thetas(1),thetas(nthetas));
elseif nthetas < 1
fprintf(fid,'%f ',thetas);
fprintf(fid,'%\n ');
end

fprintf(fid,'%d\n',nphi);
if nphi == 1
fprintf(fid,'%f\n',phi);
elseif nphi > 1
fprintf(fid,'%f %f\n',phi(1),phi(nphi));
elseif nphi < 1
fprintf(fid,'%f ',phi);
fprintf(fid,'%\n ');
end

% Write surface info: 

fprintf(fid,'%s\n',separation_line); 

 atype = surface_info.type ;
aptype = surface_info.ptype;
aitype = surface_info.itype;
  xati = surface_info.x    ; natix = length( xati );
  yati = surface_info.y    ; natiy = length( yati );
  zati = surface_info.z    ; 
atiu   = surface_info.units;
aproperties = surface_info.properties;

fprintf(fid,'%s\n', atype);
fprintf(fid,'%s\n',aptype);
fprintf(fid,'%s\n',aitype);
fprintf(fid,'%s\n',  atiu);

fprintf(fid,'%d\n',natix);
fprintf(fid,'%e  ',xati );fprintf(fid,'\n');
fprintf(fid,'%d\n',natiy);
fprintf(fid,'%e  ',yati );fprintf(fid,'\n');
for ii = 1:natiy
 	fprintf(fid,'%f ',zati(ii,:)); fprintf(fid,'\n');
end

switch aptype 
   
   case 'H'
   
   fprintf(fid,'%f %f %f %f %f\n',aproperties );

   case 'N'
   
    cpati = surface_info.cp ;
    csati = surface_info.cs ;
   rhoati = surface_info.rho;
    apati = surface_info.ap ;
    asati = surface_info.as ;
   
   for ii = 1:natiy
 	   fprintf(fid,'%f ',cpati(ii,:)); fprintf(fid,'\n');
   end
   
   for ii = 1:natiy
 	   fprintf(fid,'%f ',csati(ii,:)); fprintf(fid,'\n');
   end
   
   for ii = 1:natiy
 	   fprintf(fid,'%f ',rhoati(ii,:)); fprintf(fid,'\n');
   end
   
   for ii = 1:natiy
 	   fprintf(fid,'%f ',apati(ii,:)); fprintf(fid,'\n');
   end
   
   for ii = 1:natiy
 	   fprintf(fid,'%f ',asati(ii,:)); fprintf(fid,'\n');
   end
   
   otherwise 
   
       disp('Unknowm surface type.'), return
   
end 

% Write sound speed info: 

% Analytical profiles: 
% Exponential   : 'EXPP'
% Inverse Square: 'ISQP'
% Isovelocity   : 'ISOV'
% Linear        : 'LINP'
% Munk          : 'MUNK'
% N2 Linear     : 'N2LP'
% Parabolic     : 'PARP'

% Tabulated:
% c(x,0,0)      : 'CX00'
% c(0,y,0)      : 'C0Y0'
% c(0,0,z)      : 'C00Z' 
% c(x,y,0)      : 'CXY0'
% c(x,0,z)      : 'CX0Z'
% c(0,y,z)      : 'C0YZ'
% c(x,y,z)      : 'CXYZ'

fprintf(fid,'%s\n',separation_line); 
fprintf(fid,'%s\n',ctype);
switch ctype
   case 'EXPP'
            fprintf(fid,'%d\n',2);
	    fprintf(fid,'%f %f\n',z0(1),c0(1));
	    fprintf(fid,'%f %f\n',z0(2),c0(1));
   case 'ISOV'
            fprintf(fid,'%d\n',2);
	    fprintf(fid,'%f %f\n',z0(1),c0(1));
	    fprintf(fid,'%f %f\n',z0(2),c0(1));
   case 'ISQP'
            fprintf(fid,'%d\n',2);
	    fprintf(fid,'%f %f\n',z0(1),c0(1));
	    fprintf(fid,'%f %f\n',z0(2),c0(1));
   case 'LINP'
            fprintf(fid,'%d\n',2);
	    fprintf(fid,'%f %f\n',z0(1),c0(1));
	    fprintf(fid,'%f %f\n',z0(2),c0(1));
   case 'MUNK'
            fprintf(fid,'%d\n',2);
	    fprintf(fid,'%f %f\n',z0(1),c0(1));
	    fprintf(fid,'%f %f\n',z0(2),c0(1));
   case 'N2LP'
            fprintf(fid,'%d\n',2);
	    fprintf(fid,'%f %f\n',z0(1),c0(1));
	    fprintf(fid,'%f %f\n',z0(2),c0(1));
   case 'PARP'
            fprintf(fid,'%d\n',2);
	    fprintf(fid,'%f %f\n',z0(1),c0(1));
	    fprintf(fid,'%f %f\n',z0(2),c0(1));
   case 'CX00'
	    nx0 = length( x0 ); 
	    fprintf(fid,'%d\n',nx0);
	    fprintf(fid,'%e ' , x0);fprintf(fid,'\n');
            fprintf(fid,'%f ',  c0);fprintf(fid,'\n');
   case 'C0Y0'
	    ny0 = length( y0 ); 
	    fprintf(fid,'%d\n',ny0);
	    fprintf(fid,'%e ' , y0);fprintf(fid,'\n');
            fprintf(fid,'%f ',  c0);fprintf(fid,'\n');
   case 'C00Z'
	    nz0 = length( z0 ); 
	    fprintf(fid,'%d\n',nz0);
	    fprintf(fid,'%e ' , z0);fprintf(fid,'\n');
            fprintf(fid,'%f ',  c0);fprintf(fid,'\n');
   case 'CXY0'
	    nx0 = length( x0 );
	    ny0 = length( y0 );
	    fprintf(fid,'%d,%d\n',nx0,ny0);
	    fprintf(fid,'%e ',x0);fprintf(fid,'\n');
	    fprintf(fid,'%e ',y0);fprintf(fid,'\n');
	    for ii = 1:ny0
            fprintf(fid,'%f ',c0(ii,:)); fprintf(fid,'\n');
            end
   case 'CX0Z'
	    nx0 = length( x0 );
	    nz0 = length( z0 );
	    fprintf(fid,'%d,%d\n',nx0,nz0);
	    fprintf(fid,'%e ',x0);fprintf(fid,'\n');
	    fprintf(fid,'%e ',z0);fprintf(fid,'\n');
	    for ii = 1:nz0
            fprintf(fid,'%f ',c0(ii,:)); fprintf(fid,'\n');
            end
   case 'C0YZ'
	    ny0 = length( y0 );
	    nz0 = length( z0 );
	    fprintf(fid,'%d,%d\n',ny0,nz0);
	    fprintf(fid,'%e ',y0);fprintf(fid,'\n');
	    fprintf(fid,'%e ',z0);fprintf(fid,'\n');
	    for ii = 1:nz0
            fprintf(fid,'%f ',c0(ii,:)); fprintf(fid,'\n');
            end
   case 'CXYZ'
	    nx0 = length( x0 );   
	    ny0 = length( y0 );
	    nz0 = length( z0 );
	    fprintf(fid,'%d,%d,%d\n',nx0,ny0,nz0);
	    fprintf(fid,'%e ',x0);fprintf(fid,'\n');
	    fprintf(fid,'%e ',y0);fprintf(fid,'\n');
	    fprintf(fid,'%e ',z0);fprintf(fid,'\n');
	    for iii = 1:nz0
	    for ii  = 1:ny0
            fprintf(fid,'%f ',c0(iii,ii,:)); fprintf(fid,'\n');
            end
	    end
   otherwise
      disp('Unknown sound speed distribution.'), return
end

% Write bottom info: 

fprintf(fid,'%s\n',separation_line);
fprintf(fid,'%s\n', btype);
fprintf(fid,'%s\n',bptype);
fprintf(fid,'%s\n',bitype);
fprintf(fid,'%s\n',  btyu);

fprintf(fid,'%d\n',nbtyx);
fprintf(fid,'%e  ',xbty );fprintf(fid,'\n');
fprintf(fid,'%d\n',nbtyy);
fprintf(fid,'%e  ',ybty );fprintf(fid,'\n');
for ii = 1:nbtyy
 	fprintf(fid,'%f ',zbty(ii,:)); fprintf(fid,'\n');
end

switch bptype 
   
   case 'H'
   
   fprintf(fid,'%f %f %f %f %f\n',bproperties );

   case 'N'
   
    cpbty = bathymetry_info.cp ;
    csbty = bathymetry_info.cs ;
   rhobty = bathymetry_info.rho;
    apbty = bathymetry_info.ap ;
    asbty = bathymetry_info.as ;
   
   for ii = 1:nbtyy
 	   fprintf(fid,'%f ',cpbty(ii,:)); fprintf(fid,'\n');
   end
   
   for ii = 1:nbtyy
 	   fprintf(fid,'%f ',csbty(ii,:)); fprintf(fid,'\n');
   end
   
   for ii = 1:nbtyy
 	   fprintf(fid,'%f ',rhobty(ii,:)); fprintf(fid,'\n');
   end
   
   for ii = 1:nbtyy
 	   fprintf(fid,'%f ',apbty(ii,:)); fprintf(fid,'\n');
   end
   
   for ii = 1:nbtyy
 	   fprintf(fid,'%f ',asbty(ii,:)); fprintf(fid,'\n');
   end

   otherwise
   
      disp('Unknown bottom type.'), return 
end

% Write array configuration: 
fprintf(fid,'%s\n',separation_line);
fprintf(fid,'%d,%d,%d\n',narrayx,narrayy,narrayz);
if narrayx*narrayy*narrayz == 0
data = [array_x(:)';array_y(:)';array_z(:)'];
fprintf(fid,'%f %f %f\n ',data);
else
fprintf(fid,'%e ',array_x );fprintf(fid,'\n');
fprintf(fid,'%e ',array_y );fprintf(fid,'\n');
fprintf(fid,'%e ',array_z );fprintf(fid,'\n');
end

% Write calculation info:
fprintf(fid,'%s\n',separation_line);
fprintf(fid,'%s\n', calc_type);
fprintf(fid,'%e\n',array_miss);
fclose( fid );
